package co.edu.uptc.aj.os

import co.edu.uptc.aj.os.gui.MainWindow

fun main(args: Array<String>) {
    MainWindow(false).execute()
}